import numpy as np
import csv


class LMSE():
    def __init__(self, w, y, label, alpha, loop_max=100, theta=10e-5, reverse=1):
        '''
        :param w: 参数初始值
        :param alpha: 学习率
        :param loop_max: 最大迭代次数
        :param epsilon: 阀值
        :param k: 当前迭代数
        :param reverse: 是否是反转,用于减少计算量
        '''
        self.w = np.array([w] * y.shape[1]).astype(float)
        self.y = y
        self.label = label
        self.alpha = alpha
        self.k = 0
        self.loop_max = loop_max
        self.theta = theta
        self.reverse = reverse

    def train(self):
        for l in range(0, self.loop_max):
            for j in range(0, self.y.shape[0]):
                jna = (np.dot(self.w, self.y[j].T) - self.label[j]) * self.y[j]
                self.w = self.w - self.alpha * jna

    def decision(self, x):
        x_p = np.insert(x, 0, [1])
        value = self.reverse * np.dot(self.w, x_p.T)
        if value >= 0:
            return 1
        else:
            return -1

def readDataFromCSV(datafile, labelfile):
    dataset = []
    labels = []
    with open(datafile, 'r') as f:
        reader = csv.reader(f)
        for row in reader:
            dataset.append(row)
    with open(labelfile, 'r') as f:
        reader = csv.reader(f)
        for row in reader:
            labels.append(row)
    return dataset, labels

if __name__=='__main__':
    x_p = np.array([[1, 1], [2, 2], [2, 0]])
    x_n = np.array([[0, 0], [1, 0], [0, 1]])
    pending_p = np.array([1] * x_p.shape[0])
    pending_n = np.array([1] * x_n.shape[0])
    y_p = np.insert(x_p, 0, pending_p, axis=1)
    y_n = np.insert(x_n, 0, pending_n, axis=1)
    y = np.vstack((y_p, y_n))
    label = np.array([1, 1, 1, -1, -1, -1])
    w = 0.1
    alpha = 0.01
    loop_max = 100
    model = LMSE(w, y, label, alpha, loop_max)
    model.train()
    print(model.w)

