import numpy as np
import csv
import copy


class LMSE():
    def __init__(self, w, y, label, alpha, loop_max=100, theta=10e-5, reverse=1):
        '''
        :param w: 参数初始值
        :param alpha: 学习率
        :param loop_max: 最大迭代次数
        :param epsilon: 阀值
        :param k: 当前迭代数
        :param reverse: 是否是反转,用于减少计算量
        '''
        self.w = np.array([w] * y.shape[1]).astype(float)
        self.y = y
        self.label = label
        self.alpha = alpha
        self.k = 0
        self.loop_max = loop_max
        self.theta = theta
        self.reverse = reverse

    def train(self):
        for l in range(0, self.loop_max):
            for j in range(0, self.y.shape[0]):
                jna = (np.dot(self.w, self.y[j].T)-self.label[j])*self.y[j]
                self.w = self.w - self.alpha * jna

    def decision(self, x):
        x_p = np.insert(x, 0, [1])
        value = self.reverse*np.dot(self.w, x_p.T)
        if value >= 0:
            return 1
        else:
            return -1

def readDataFromCSV(datafile, labelfile):
    dataset = []
    labels = []
    with open(datafile, 'r') as f:
        reader = csv.reader(f)
        for row in reader:
            dataset.append(row)
    with open(labelfile, 'r') as f:
        reader = csv.reader(f)
        for row in reader:
            labels.append(row)
    return dataset, labels

def shuffledData(dataset1, dataset2):
    dataset = np.vstack((dataset1, dataset2))
    label = [1]*dataset1.shape[0]
    label.extend([-1]*dataset2.shape[0])
    label = np.array(label)
    permutation = np.random.permutation(dataset.shape[0])
    shuffled_dataset = dataset[permutation, :]
    shuffled_label = label[permutation]
    return shuffled_dataset, shuffled_label

if __name__=='__main__':
    dataset, labels = readDataFromCSV('data/TrainSamples.csv', 'data/TrainLabels.csv')
    dataset = np.array(dataset).astype(float)
    pending = np.array([1] * dataset.shape[0]).astype(float)
    dataset = np.insert(dataset, 0, pending, axis=1)
    labels = np.array(labels)
    classifiedDataSet = [[], [], [], [], [], [], [], [], [], []]
    for i in range(0, labels.shape[0]):
       temp = int(labels[i, 0])
       classifiedDataSet[temp].append(dataset[i])

    w = 10e-5
    alpha = 10e-10
    loop_max = 10
    classifer = [[], [], [], [], [], [], [], [], [], []]


    # dataset, label = shuffledData(np.array(classifiedDataSet[0]), np.array(classifiedDataSet[1]))
    # print(label)
    # model = LMSE(w, dataset, label, alpha, loop_max)
    # model.train()

    for i in range(0, 10):
        for j in range(0, 10):
            if i == j:
                classifer[i].append('null')
            elif i > j:
                sub = copy.deepcopy(classifer[j][i])
                sub.reverse = -1
                classifer[i].append(sub)
            else:
                dataset, label = shuffledData(np.array(classifiedDataSet[i]), np.array(classifiedDataSet[j]))
                model = LMSE(w, dataset, label, alpha, loop_max)
                model.train()
                classifer[i].append(model)

    testDataset, testLabels = readDataFromCSV('data/TestSamples.csv', 'data/TestLabels.csv')
    testDataset = np.array(testDataset).astype(float)
    testLabels = np.array(testLabels).astype(int)
    predictLabel = []
    for index in range(0, testDataset.shape[0]):
        vote = [0]*10
        trueLabel = testLabels[index, 0]
        for j in range(0, 10):
            if classifer[trueLabel][j] == 'null':
                continue
            elif trueLabel == j:
                continue
            else:
                value = classifer[trueLabel][j].decision(testDataset[index])
                if value == 1:
                    vote[trueLabel] = vote[trueLabel]+1

        predictLabel.append(np.argmax(vote))
        # if vote[np.argmax(vote)] == 8:
        #     predictLabel.append(np.argmax(vote))
        # else:
        #     predictLabel.append(-1)



    total = 0
    for index in range(0, testLabels.shape[0]):
        if testLabels[index, 0] == predictLabel[index]:
            total += 1
    print ('accuracy:', total/testLabels.shape[0])






